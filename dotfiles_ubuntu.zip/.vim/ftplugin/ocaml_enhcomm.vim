set commentstring=(*%s*)
